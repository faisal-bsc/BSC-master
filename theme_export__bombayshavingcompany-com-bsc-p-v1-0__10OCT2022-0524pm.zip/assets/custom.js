/**
 * Include your custom JavaScript here.
 *
 * We also offer some hooks so you can plug your own logic. For instance, if you want to be notified when the variant
 * changes on product page, you can attach a listener to the document:
 *
 * document.addEventListener('variant:changed', function(event) {
 *   var variant = event.detail.variant; // Gives you access to the whole variant details
 * });
 *
 * You can also add a listener whenever a product is added to the cart:
 *
 * document.addEventListener('product:added', function(event) {
 *   var variant = event.detail.variant; // Get the variant that was added
 *   var quantity = event.detail.quantity; // Get the quantity that was added
 * });
 *
 * If you just want to force refresh the mini-cart without adding a specific product, you can trigger the event
 * "cart:refresh" in a similar way (in that case, passing the quantity is not necessary):
 *
 * document.documentElement.dispatchEvent(new CustomEvent('cart:refresh', {
 *   bubbles: true
 * }));
 */

$('.ad_to_cart_coll').click(function(){    
   
  var ID = $(this).attr("data-var_id");
  addItemToCart( ID, 1);    // paste your id product number
  $('.cart_dr').trigger( "click" );
          $("#sidebar-cart").attr("aria-hidden","false");
  _tfa.push({notify: 'event', name: 'addtocart', id: 1489967});
  
  
});

// function addItemToCart(variant_id, qty) {
//   data = {
//     "id": variant_id,
//     "quantity": qty
//   }
//   jQuery.ajax({
//     type: 'POST',
//     url: '/cart/add.js',
//     data: data,
//     dataType: 'json',
//     success: function() { 
//       document.documentElement.dispatchEvent(new CustomEvent('cart:refresh', {
//         bubbles: true  //this code is for prestige theme, is to refresh the cart
//       }));

//     }   
    
//   }); 
//  seconds = upgradeTime;
// }


function addItemToCart(variant_id, qty) {
  data = {
    "id": variant_id,
    "quantity": qty
  }

  fetch(
    "/cart/add.js", {
      'method': "POST",
      'Content-Type': 'application/json',
      'body': JSON.stringify(data)
    }
  )
  .then(function() { 
    document.documentElement.dispatchEvent(new CustomEvent('cart:refresh', {
      bubbles: true  //this code is for prestige theme, is to refresh the cart
    }));
  })
  .catch(err => null)

  seconds = upgradeTime;

}



$(window).ready(function(){
  $('.Product__Gallery').addClass("notextt")
  setInterval(function(){ 
    $('.Product__Gallery').removeClass("notextt");
    $('.viewsimilar').fadeIn();
  }, 4000);
});$('.ProductForm__AddToCart').click(function(){    
  seconds = upgradeTime;
});


var upgradeTime = 600; // seconds
    var seconds = upgradeTime;

    function timer() {
        var days = Math.floor(seconds / 24 / 60 / 60);
        var hoursLeft = Math.floor((seconds) - (days * 86400));
        var hours = Math.floor(hoursLeft / 3600);
        var minutesLeft = Math.floor((hoursLeft) - (hours * 3600));
        var minutes = Math.floor(minutesLeft / 60);
        var remainingSeconds = seconds % 60;

        function pad(n) {
            return (n < 10 ? "0" + n : n);
        }
        document.getElementById('timer').innerHTML = pad(minutes) + ":" + pad(remainingSeconds);
        if (seconds == 0) {
            seconds = upgradeTime;

        } else {
            seconds--;
        }
    }
    var countdownTimer = setInterval('timer()', 1000);

document.addEventListener('quizKitAddToCartSuccess', function () {
  	  document.documentElement.dispatchEvent(new CustomEvent('cart:refresh', {
        bubbles: true
      }));

      document.querySelector('a[href="/cart"]').click();
	}, false);

$(".vewsim").click(function() {
    $('html, body').animate({
        scrollTop: $(".cbb-frequently-bought-container ").offset().top - 200
    }, 1000);
});
