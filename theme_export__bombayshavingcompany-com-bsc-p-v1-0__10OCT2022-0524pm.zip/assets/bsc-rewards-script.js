var $jscomp = $jscomp || {};
$jscomp.scope = {};
$jscomp.createTemplateTagFirstArg = function (a) {
  return (a.raw = a);
};
$jscomp.createTemplateTagFirstArgWithRaw = function (a, b) {
  a.raw = b;
  return a;
};
$jscomp.ASSUME_ES5 = !1;
$jscomp.ASSUME_NO_NATIVE_MAP = !1;
$jscomp.ASSUME_NO_NATIVE_SET = !1;
$jscomp.SIMPLE_FROUND_POLYFILL = !1;
$jscomp.ISOLATE_POLYFILLS = !1;
$jscomp.FORCE_POLYFILL_PROMISE = !1;
$jscomp.FORCE_POLYFILL_PROMISE_WHEN_NO_UNHANDLED_REJECTION = !1;
$jscomp.defineProperty =
  $jscomp.ASSUME_ES5 || "function" == typeof Object.defineProperties
    ? Object.defineProperty
    : function (a, b, c) {
        if (a == Array.prototype || a == Object.prototype) return a;
        a[b] = c.value;
        return a;
      };
$jscomp.getGlobal = function (a) {
  a = [
    "object" == typeof globalThis && globalThis,
    a,
    "object" == typeof window && window,
    "object" == typeof self && self,
    "object" == typeof global && global,
  ];
  for (var b = 0; b < a.length; ++b) {
    var c = a[b];
    if (c && c.Math == Math) return c;
  }
  throw Error("Cannot find global object");
};
$jscomp.global = $jscomp.getGlobal(this);
$jscomp.IS_SYMBOL_NATIVE =
  "function" === typeof Symbol && "symbol" === typeof Symbol("x");
$jscomp.TRUST_ES6_POLYFILLS =
  !$jscomp.ISOLATE_POLYFILLS || $jscomp.IS_SYMBOL_NATIVE;
$jscomp.polyfills = {};
$jscomp.propertyToPolyfillSymbol = {};
$jscomp.POLYFILL_PREFIX = "$jscp$";
var $jscomp$lookupPolyfilledValue = function (a, b) {
  var c = $jscomp.propertyToPolyfillSymbol[b];
  if (null == c) return a[b];
  c = a[c];
  return void 0 !== c ? c : a[b];
};
$jscomp.polyfill = function (a, b, c, d) {
  b &&
    ($jscomp.ISOLATE_POLYFILLS
      ? $jscomp.polyfillIsolated(a, b, c, d)
      : $jscomp.polyfillUnisolated(a, b, c, d));
};
$jscomp.polyfillUnisolated = function (a, b, c, d) {
  c = $jscomp.global;
  a = a.split(".");
  for (d = 0; d < a.length - 1; d++) {
    var e = a[d];
    if (!(e in c)) return;
    c = c[e];
  }
  a = a[a.length - 1];
  d = c[a];
  b = b(d);
  b != d &&
    null != b &&
    $jscomp.defineProperty(c, a, { configurable: !0, writable: !0, value: b });
};
$jscomp.polyfillIsolated = function (a, b, c, d) {
  var e = a.split(".");
  a = 1 === e.length;
  d = e[0];
  d = !a && d in $jscomp.polyfills ? $jscomp.polyfills : $jscomp.global;
  for (var f = 0; f < e.length - 1; f++) {
    var g = e[f];
    if (!(g in d)) return;
    d = d[g];
  }
  e = e[e.length - 1];
  c = $jscomp.IS_SYMBOL_NATIVE && "es6" === c ? d[e] : null;
  b = b(c);
  null != b &&
    (a
      ? $jscomp.defineProperty($jscomp.polyfills, e, {
          configurable: !0,
          writable: !0,
          value: b,
        })
      : b !== c &&
        (void 0 === $jscomp.propertyToPolyfillSymbol[e] &&
          ((c = (1e9 * Math.random()) >>> 0),
          ($jscomp.propertyToPolyfillSymbol[e] = $jscomp.IS_SYMBOL_NATIVE
            ? $jscomp.global.Symbol(e)
            : $jscomp.POLYFILL_PREFIX + c + "$" + e)),
        $jscomp.defineProperty(d, $jscomp.propertyToPolyfillSymbol[e], {
          configurable: !0,
          writable: !0,
          value: b,
        })));
};
$jscomp.underscoreProtoCanBeSet = function () {
  var a = { a: !0 },
    b = {};
  try {
    return (b.__proto__ = a), b.a;
  } catch (c) {}
  return !1;
};
$jscomp.setPrototypeOf =
  $jscomp.TRUST_ES6_POLYFILLS && "function" == typeof Object.setPrototypeOf
    ? Object.setPrototypeOf
    : $jscomp.underscoreProtoCanBeSet()
    ? function (a, b) {
        a.__proto__ = b;
        if (a.__proto__ !== b) throw new TypeError(a + " is not extensible");
        return a;
      }
    : null;
$jscomp.arrayIteratorImpl = function (a) {
  var b = 0;
  return function () {
    return b < a.length ? { done: !1, value: a[b++] } : { done: !0 };
  };
};
$jscomp.arrayIterator = function (a) {
  return { next: $jscomp.arrayIteratorImpl(a) };
};
$jscomp.makeIterator = function (a) {
  var b = "undefined" != typeof Symbol && Symbol.iterator && a[Symbol.iterator];
  return b ? b.call(a) : $jscomp.arrayIterator(a);
};
$jscomp.generator = {};
$jscomp.generator.ensureIteratorResultIsObject_ = function (a) {
  if (!(a instanceof Object))
    throw new TypeError("Iterator result " + a + " is not an object");
};
$jscomp.generator.Context = function () {
  this.isRunning_ = !1;
  this.yieldAllIterator_ = null;
  this.yieldResult = void 0;
  this.nextAddress = 1;
  this.finallyAddress_ = this.catchAddress_ = 0;
  this.finallyContexts_ = this.abruptCompletion_ = null;
};
$jscomp.generator.Context.prototype.start_ = function () {
  if (this.isRunning_) throw new TypeError("Generator is already running");
  this.isRunning_ = !0;
};
$jscomp.generator.Context.prototype.stop_ = function () {
  this.isRunning_ = !1;
};
$jscomp.generator.Context.prototype.jumpToErrorHandler_ = function () {
  this.nextAddress = this.catchAddress_ || this.finallyAddress_;
};
$jscomp.generator.Context.prototype.next_ = function (a) {
  this.yieldResult = a;
};
$jscomp.generator.Context.prototype.throw_ = function (a) {
  this.abruptCompletion_ = { exception: a, isException: !0 };
  this.jumpToErrorHandler_();
};
$jscomp.generator.Context.prototype["return"] = function (a) {
  this.abruptCompletion_ = { return: a };
  this.nextAddress = this.finallyAddress_;
};
$jscomp.generator.Context.prototype.jumpThroughFinallyBlocks = function (a) {
  this.abruptCompletion_ = { jumpTo: a };
  this.nextAddress = this.finallyAddress_;
};
$jscomp.generator.Context.prototype.yield = function (a, b) {
  this.nextAddress = b;
  return { value: a };
};
$jscomp.generator.Context.prototype.yieldAll = function (a, b) {
  var c = $jscomp.makeIterator(a),
    d = c.next();
  $jscomp.generator.ensureIteratorResultIsObject_(d);
  if (d.done) (this.yieldResult = d.value), (this.nextAddress = b);
  else return (this.yieldAllIterator_ = c), this.yield(d.value, b);
};
$jscomp.generator.Context.prototype.jumpTo = function (a) {
  this.nextAddress = a;
};
$jscomp.generator.Context.prototype.jumpToEnd = function () {
  this.nextAddress = 0;
};
$jscomp.generator.Context.prototype.setCatchFinallyBlocks = function (a, b) {
  this.catchAddress_ = a;
  void 0 != b && (this.finallyAddress_ = b);
};
$jscomp.generator.Context.prototype.setFinallyBlock = function (a) {
  this.catchAddress_ = 0;
  this.finallyAddress_ = a || 0;
};
$jscomp.generator.Context.prototype.leaveTryBlock = function (a, b) {
  this.nextAddress = a;
  this.catchAddress_ = b || 0;
};
$jscomp.generator.Context.prototype.enterCatchBlock = function (a) {
  this.catchAddress_ = a || 0;
  a = this.abruptCompletion_.exception;
  this.abruptCompletion_ = null;
  return a;
};
$jscomp.generator.Context.prototype.enterFinallyBlock = function (a, b, c) {
  c
    ? (this.finallyContexts_[c] = this.abruptCompletion_)
    : (this.finallyContexts_ = [this.abruptCompletion_]);
  this.catchAddress_ = a || 0;
  this.finallyAddress_ = b || 0;
};
$jscomp.generator.Context.prototype.leaveFinallyBlock = function (a, b) {
  var c = this.finallyContexts_.splice(b || 0)[0];
  if ((c = this.abruptCompletion_ = this.abruptCompletion_ || c)) {
    if (c.isException) return this.jumpToErrorHandler_();
    void 0 != c.jumpTo && this.finallyAddress_ < c.jumpTo
      ? ((this.nextAddress = c.jumpTo), (this.abruptCompletion_ = null))
      : (this.nextAddress = this.finallyAddress_);
  } else this.nextAddress = a;
};
$jscomp.generator.Context.prototype.forIn = function (a) {
  return new $jscomp.generator.Context.PropertyIterator(a);
};
$jscomp.generator.Context.PropertyIterator = function (a) {
  this.object_ = a;
  this.properties_ = [];
  for (var b in a) this.properties_.push(b);
  this.properties_.reverse();
};
$jscomp.generator.Context.PropertyIterator.prototype.getNext = function () {
  for (; 0 < this.properties_.length; ) {
    var a = this.properties_.pop();
    if (a in this.object_) return a;
  }
  return null;
};
$jscomp.generator.Engine_ = function (a) {
  this.context_ = new $jscomp.generator.Context();
  this.program_ = a;
};
$jscomp.generator.Engine_.prototype.next_ = function (a) {
  this.context_.start_();
  if (this.context_.yieldAllIterator_)
    return this.yieldAllStep_(
      this.context_.yieldAllIterator_.next,
      a,
      this.context_.next_
    );
  this.context_.next_(a);
  return this.nextStep_();
};
$jscomp.generator.Engine_.prototype.return_ = function (a) {
  this.context_.start_();
  var b = this.context_.yieldAllIterator_;
  if (b)
    return this.yieldAllStep_(
      "return" in b
        ? b["return"]
        : function (c) {
            return { value: c, done: !0 };
          },
      a,
      this.context_["return"]
    );
  this.context_["return"](a);
  return this.nextStep_();
};
$jscomp.generator.Engine_.prototype.throw_ = function (a) {
  this.context_.start_();
  if (this.context_.yieldAllIterator_)
    return this.yieldAllStep_(
      this.context_.yieldAllIterator_["throw"],
      a,
      this.context_.next_
    );
  this.context_.throw_(a);
  return this.nextStep_();
};
$jscomp.generator.Engine_.prototype.yieldAllStep_ = function (a, b, c) {
  try {
    var d = a.call(this.context_.yieldAllIterator_, b);
    $jscomp.generator.ensureIteratorResultIsObject_(d);
    if (!d.done) return this.context_.stop_(), d;
    var e = d.value;
  } catch (f) {
    return (
      (this.context_.yieldAllIterator_ = null),
      this.context_.throw_(f),
      this.nextStep_()
    );
  }
  this.context_.yieldAllIterator_ = null;
  c.call(this.context_, e);
  return this.nextStep_();
};
$jscomp.generator.Engine_.prototype.nextStep_ = function () {
  for (; this.context_.nextAddress; )
    try {
      var a = this.program_(this.context_);
      if (a) return this.context_.stop_(), { value: a.value, done: !1 };
    } catch (b) {
      (this.context_.yieldResult = void 0), this.context_.throw_(b);
    }
  this.context_.stop_();
  if (this.context_.abruptCompletion_) {
    a = this.context_.abruptCompletion_;
    this.context_.abruptCompletion_ = null;
    if (a.isException) throw a.exception;
    return { value: a["return"], done: !0 };
  }
  return { value: void 0, done: !0 };
};
$jscomp.generator.Generator_ = function (a) {
  this.next = function (b) {
    return a.next_(b);
  };
  this["throw"] = function (b) {
    return a.throw_(b);
  };
  this["return"] = function (b) {
    return a.return_(b);
  };
  this[Symbol.iterator] = function () {
    return this;
  };
};
$jscomp.generator.createGenerator = function (a, b) {
  var c = new $jscomp.generator.Generator_(new $jscomp.generator.Engine_(b));
  $jscomp.setPrototypeOf &&
    a.prototype &&
    $jscomp.setPrototypeOf(c, a.prototype);
  return c;
};
$jscomp.asyncExecutePromiseGenerator = function (a) {
  function b(d) {
    return a.next(d);
  }
  function c(d) {
    return a["throw"](d);
  }
  return new Promise(function (d, e) {
    function f(g) {
      g.done ? d(g.value) : Promise.resolve(g.value).then(b, c).then(f, e);
    }
    f(a.next());
  });
};
$jscomp.asyncExecutePromiseGeneratorFunction = function (a) {
  return $jscomp.asyncExecutePromiseGenerator(a());
};
$jscomp.asyncExecutePromiseGeneratorProgram = function (a) {
  return $jscomp.asyncExecutePromiseGenerator(
    new $jscomp.generator.Generator_(new $jscomp.generator.Engine_(a))
  );
};
var BACKEND_URL = "https://rewards-backend.superassistant.io",
  shopDomain_rs,
  customerId_rs;
void 0 !== __st.cid && (customerId_rs = __st.cid);
shopDomain_rs = Shopify.shop;
var pLocation = window.location.host,
  launcherIconData,
  script_nudge = document.createElement("script");
script_nudge.src =
  "https://rewards-popup-widget.s3.ap-south-1.amazonaws.com/nudges/nudges.js";
document.body.appendChild(script_nudge);
var fontLink_rs = document.createElement("link");
fontLink_rs.href =
  "https://fonts.googleapis.com/css2?family=Poppins:wght@100;300;400;500;700&display=swap";
fontLink_rs.rel = "stylesheet";
document.body.appendChild(fontLink_rs);
var styleRewards = document.createElement("style");
styleRewards.textContent =
  "\n@keyframes superFadeScaleIn {\n  0% {\n    opacity: 0;\n    transform: scale(.8);\n    visibility: hidden;\n  }\n  100% {\n    opacity: 1;\n    transform: scale(1);\n    visibility: visible;\n  }\n}\n@keyframes superFadeSlideUp {\n  0% {\n    opacity: 0;\n    transform: translate3d(0,10px,0);\n}\n100% {\n    opacity: 1;\n    transform: translateZ(0);\n}\n}\n@keyframes superFadeSlideDown {\n  0% {\n    opacity: 1;\n    transform: translateZ(0);\n}\n100% {\n    opacity: 0;\n    transform: translate3d(0,10px,0);\n}\n}\n";
var referrer = new URLSearchParams(location.search).get("ref");
referrer && localStorage.setItem("SA_rewards_ref", referrer);
var iframeWrapperDiv = document.createElement("div");
iframeWrapperDiv.setAttribute("id", "rewards-widget");
iframeWrapperDiv.style.cssText =
  "\n   height: calc(100% - 120px);\n   max-height: 600px;\n   width:360px;\n   position:fixed;\n   bottom:0;\n   z-index : 2147483647 !important;\n   border-radius:10px;\n   overflow:hidden;\n   box-shadow: 0 0 80px 0 rgb(0 0 0 / 12%);\n  display:none;\n  -webkit-animation: superFadeSlideUp .2s ease-in!important;\n  animation: superFadeSlideUp .2s ease-in!important;\n  background-color: #ffffff;\n   ";
document.body.appendChild(iframeWrapperDiv);
var iframe = document.createElement("iframe");
iframe.name = "rewards-widget-iframe";
iframe.src =
  "https://d192zi39cvatzt.cloudfront.net/?shopDomain=" +
  shopDomain_rs +
  "&customerId=" +
  customerId_rs +
  "&parentLocation=" +
  pLocation;
iframe.allow = "clipboard-write; clipboard-read;";
iframeWrapperDiv.appendChild(iframe);
if (window.matchMedia) {
  var mq = window.matchMedia("(min-width: 768px)");
  mq.addListener(handleMobileChange);
  handleMobileChange(mq);
}
iframe.style.cssText = "width:100%; height: 100%; border:none;";
iframeWrapperDiv.appendChild(iframe);
var launcherDiv = document.createElement("div");
launcherDiv.setAttribute("id", "launcher");
launcherDiv.style.cssText =
  "\n   height:60px;\n   min-width:60px;\n   position:fixed;\n   bottom:0;\n   z-index:2147483646 !important;\n   border-radius:50px;\n   margin: 0 20px 20px 0;\n   font-size:20px;\n   display:flex;\n   justify-content:center;\n   align-items:center;\n   cursor:pointer;\n   box-shadow: 0 0 80px 20px rgb(0 0 0 / 12%);\n   -webkit-animation: superFadeScaleIn .2s ease-in-out!important;\n    animation: superFadeScaleIn .2s ease-in-out!important;\n    -webkit-animation-delay: .15s!important;\n    animation-delay: .15s!important;\n    -webkit-animation-fill-mode: forwards!important;\n    animation-fill-mode: forwards!important;\n    transition: all .2s ease-in-out!important;\n\n   ";
var launcherIcon = document.createElement("img");
launcherIcon.style.cssText += "\nwidth:30px;\nheight:30px\n";
launcherDiv.appendChild(launcherIcon);
var launcherText = document.createElement("span");
launcherText.style.cssText +=
  "\nfont-weight: 400;\nfont-size: 16px;\nmargin: 0  0  0 12px;\nfont-family: 'Poppins', sans-serif;\n";
launcherDiv.appendChild(launcherText);
launcherDiv.addEventListener("click", function () {
  removeLocationHash();
  if ("none" === iframeWrapperDiv.style.display)
    (iframeWrapperDiv.style.display = "initial"),
      (launcherIcon.style.display = "initial"),
      (launcherIcon.src =
        "data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='20' height='20' viewBox='0 0 20 20'%3E%3Cpath fill='%23FFF' fill-rule='nonzero' d='M11.06 10l3.713 3.712a.75.75 0 0 1-1.06 1.061L10 11.061l-3.712 3.712a.75.75 0 0 1-1.061-1.06L8.939 10 5.227 6.288a.75.75 0 1 1 1.06-1.061L10 8.939l3.712-3.712a.75.75 0 0 1 1.061 1.06L11.061 10z'/%3E%3C/svg%3E"),
      (launcherText.textContent = ""),
      (launcherDiv.style.padding = "0"),
      (launcherText.style.display = "none");
  else {
    var a;
    "text" === (null == (a = launcherIconData) ? void 0 : a.textVisible)
      ? (launcherIcon.style.display = "none")
      : (launcherIcon.style.display = "initial");
    iframeWrapperDiv.style.display = "none";
    setLauncherIcon(launcherIconData);
    launcherText.textContent = launcherIconData.widgetText;
    var b, c;
    "both" === (null == (b = launcherIconData) ? void 0 : b.textVisible) ||
    "text" === (null == (c = launcherIconData) ? void 0 : c.textVisible)
      ? (launcherDiv.style.padding = "0 20px")
      : (launcherDiv.style.padding = "0");
    var d, e;
    "both" === (null == (d = launcherIconData) ? void 0 : d.textVisible) ||
    "text" === (null == (e = launcherIconData) ? void 0 : e.textVisible)
      ? (launcherText.style.display = "initial")
      : (launcherText.style.display = "none");
  }
});
function setLauncherIcon(a) {
  switch (null == a ? void 0 : a.widgetIcon) {
    case "fa-gift":
      var b;
      launcherIcon.src =
        "https://cdn.sweettooth.io/v1/images/launcher_icons/present.svg?color=%23" +
        (null == a ? void 0 : null == (b = a.font) ? void 0 : b.slice(1));
      break;
    case "fa-shopping-bag":
      var c;
      launcherIcon.src =
        "https://cdn.sweettooth.io/v1/images/launcher_icons/bag.svg?color=%23" +
        (null == a ? void 0 : null == (c = a.font) ? void 0 : c.slice(1));
      break;
    case "fa-tags":
      var d;
      launcherIcon.src =
        "https://cdn.sweettooth.io/v1/images/launcher_icons/tag.svg?color=%23" +
        (null == a ? void 0 : null == (d = a.font) ? void 0 : d.slice(1));
      break;
    case "fa-crown":
      var e;
      launcherIcon.src =
        "https://cdn.sweettooth.io/v1/images/launcher_icons/crown.svg?color=%23" +
        (null == a ? void 0 : null == (e = a.font) ? void 0 : e.slice(1));
      break;
    case "fa-star":
      var f;
      launcherIcon.src =
        "https://cdn.sweettooth.io/v1/images/launcher_icons/star.svg?color=%23" +
        (null == a ? void 0 : null == (f = a.font) ? void 0 : f.slice(1));
      break;
    default:
      var g;
      launcherIcon.src =
        "https://cdn.sweettooth.io/v1/images/launcher_icons/present.svg?color=%23" +
        (null == a ? void 0 : null == (g = a.font) ? void 0 : g.slice(1));
  }
}
var mediaQuery = window.matchMedia("(max-width: 550px)");
function handleMobileChange(a, b) {
  iframeWrapperDiv.style.cssText = a.matches
    ? iframeWrapperDiv.style.cssText +
      "\n    width: 100%;\n    height: 100%;\n    max-height: 100vh;\n    max-width: 100vw;\n    margin: 0;\n    inset:0;\n    border-radius: 0;\n    "
    : iframeWrapperDiv.style.cssText +
      ("\n   height: calc(100% - 120px);\n   max-height: 600px;\n   width:360px;\n   inset:unset;\n   " +
        b +
        "\n   bottom:0;\n   border-radius:10px;\n   ");
}
mediaQuery.addListener(handleMobileChange);
(function () {
  var a, b, c, d, e, f, g, k, l, m, n, p, q, r, t;
  return $jscomp.asyncExecutePromiseGeneratorProgram(function (h) {
    if (1 == h.nextAddress)
      return h.yield(
        fetch(
          BACKEND_URL +
            "/launcher-icon?shopDomain=" +
            shopDomain_rs +
            "&customerId=" +
            customerId_rs
        ),
        2
      );
    if (3 != h.nextAddress) return (a = h.yieldResult), h.yield(a.json(), 3);
    b = h.yieldResult;
    ((null == (c = b) ? 0 : c.isPointsActive) ||
      (null == (d = b) ? 0 : d.isReferralsActive) ||
      (null == (e = b) ? 0 : e.isGiftcardsActive)) &&
      (null != (k = null == (f = b) ? void 0 : f.isPopupWidgetActive)
        ? k
        : 1) &&
      (null == (g = b) || !g.isCustomerBan) &&
      document.body.appendChild(launcherDiv);
    launcherIconData = b.theme;
    launcherDiv.style.color = launcherIconData.font;
    launcherDiv.style.backgroundColor = launcherIconData.hexColor;
    "right" === (null == (l = launcherIconData) ? void 0 : l.placement)
      ? ((launcherDiv.style.right = "0"),
        (launcherDiv.style.margin =
          "0 " +
          launcherIconData.positionSide +
          "px " +
          launcherIconData.positionBottom +
          "px 0"),
        (iframeWrapperDiv.style.right = "0"),
        (iframeWrapperDiv.style.margin =
          "0 " +
          launcherIconData.positionSide +
          "px " +
          (parseInt(launcherIconData.positionBottom) + 82) +
          "px 0"))
      : ((launcherDiv.style.left = "0"),
        (launcherDiv.style.margin =
          "0 0 " +
          (null == (m = launcherIconData) ? void 0 : m.positionBottom) +
          "px " +
          (null == (n = launcherIconData) ? void 0 : n.positionSide) +
          "px"),
        (iframeWrapperDiv.style.left = "0"),
        (iframeWrapperDiv.style.margin =
          "0 0 " +
          (parseInt(launcherIconData.positionBottom) + 82) +
          "px " +
          launcherIconData.positionSide +
          "px"));
    setLauncherIcon(b.theme);
    switch (null == (p = launcherIconData) ? void 0 : p.textVisible) {
      case "both":
        launcherText.style.display = "initial";
        launcherText.textContent =
          null == (q = launcherIconData) ? void 0 : q.widgetText;
        launcherDiv.style.padding = "0 20px";
        break;
      case "text":
        launcherText.style.display = "initial";
        launcherText.textContent =
          null == (r = launcherIconData) ? void 0 : r.widgetText;
        launcherDiv.style.padding = "0 20px";
        launcherIcon.style.display = "none";
        break;
      case "icon":
        launcherText.textContent = "";
        launcherDiv.style.padding = "0";
        launcherText.style.display = "none";
        break;
      default:
        launcherText.style.display = "none";
    }
    handleMobileChange(
      mediaQuery,
      "right" === (null == (t = launcherIconData) ? void 0 : t.placement)
        ? "right:0;"
        : "left:0;"
    );
    h.jumpToEnd();
  });
})();
function sendMessageToIframe() {
  console.log("sendMessageToIframe");
  try {
    var a = iframe.contentWindow;
    a.postMessage(
      {
        shopDomain: shopDomain_rs,
        customerId: customerId_rs,
        parentLocation: window.location.host,
      },
      "https://reward-cloudfront-test.superassistant.io"
    );
    console.log("try");
    console.log(a);
  } catch (b) {
    console.log("err", b),
      iframe.contentWindow.contentWindow.postMessage(
        {
          shopDomain: shopDomain_rs,
          customerId: customerId_rs,
          parentLocation: window.location.host,
        },
        "*"
      );
  }
}
function getData(a) {
  var b;
  if ("object" == typeof a.data && (null == (b = a.data) ? 0 : b.display))
    if (
      ((iframeWrapperDiv.style.display = a.data.display),
      removeLocationHash(),
      "none" === a.data.display)
    ) {
      setLauncherIcon(launcherIconData);
      var c;
      launcherText.textContent =
        null == (c = launcherIconData) ? void 0 : c.widgetText;
      var d, e;
      "both" === (null == (d = launcherIconData) ? void 0 : d.textVisible) ||
      "text" === (null == (e = launcherIconData) ? void 0 : e.textVisible)
        ? (launcherDiv.style.padding = "0 20px")
        : (launcherDiv.style.padding = "0");
      var f, g;
      "both" === (null == (f = launcherIconData) ? void 0 : f.textVisible) ||
      "text" === (null == (g = launcherIconData) ? void 0 : g.textVisible)
        ? (launcherText.style.display = "initial")
        : (launcherText.style.display = "none");
    } else
      (iframeWrapperDiv.style.display = "initial"),
        (launcherIcon.style.display = "initial"),
        (launcherIcon.src =
          "data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='20' height='20' viewBox='0 0 20 20'%3E%3Cpath fill='%23FFF' fill-rule='nonzero' d='M11.06 10l3.713 3.712a.75.75 0 0 1-1.06 1.061L10 11.061l-3.712 3.712a.75.75 0 0 1-1.061-1.06L8.939 10 5.227 6.288a.75.75 0 1 1 1.06-1.061L10 8.939l3.712-3.712a.75.75 0 0 1 1.061 1.06L11.061 10z'/%3E%3C/svg%3E"),
        (launcherText.textContent = ""),
        (launcherDiv.style.padding = "0"),
        (launcherText.style.display = "none");
}
window.addEventListener("message", getData, !1);
var referralEventInterval = setInterval(function () {
  var a, b;
  return $jscomp.asyncExecutePromiseGeneratorProgram(function (c) {
    a = localStorage.getItem("SA_rewards_ref");
    b = localStorage.getItem("Referral_reward");
    if (null === a || !customerId_rs || null !== b) return c.jumpTo(0);
    console.log("setInterval in");
    localStorage.removeItem("SA_rewards_ref");
    localStorage.setItem("Referral_reward", !0);
    return c.yield(
      fetch(
        BACKEND_URL +
          "/referral-reward/" +
          customerId_rs +
          "?shopDomain=" +
          shopDomain_rs,
        {
          method: "post",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ referrerCode: a }),
        }
      ),
      0
    );
  });
}, 5e3);
function sendHashToIframe(a) {
  iframe.contentWindow.postMessage({ superHash: a }, "*");
}
function removeLocationHash() {
  var a = window.location.toString();
  a = a.substring(0, a.indexOf("#"));
  window.history.replaceState({}, document.title, a);
}
var locationHashInterval = setInterval(function () {
  sendHashToIframe(window.location.hash);
}, 500);
